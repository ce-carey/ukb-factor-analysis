# univariate modification indices
#

modindices <- function(object,
                       standardized = TRUE,
                       cov.std = TRUE,
                       information = "expected",

                       # power statistics?
                       power = FALSE,
                       delta = 0.1,
                       alpha = 0.05,
                       high.power = 0.75,

                       # customize output
                       sort. = FALSE,
                       minimum.value = 0.0,
                       maximum.number = nrow(LIST),
                       free.remove = TRUE,
                       na.remove = TRUE,
                       op = NULL) {

    # check if model has converged
    if(object@optim$npar > 0L && !object@optim$converged) {
        warning("lavaan WARNING: model did not converge")
    }

    # not ready for estimator = "PML"
    if(object@Options$estimator == "PML") {
        stop("lavaan WARNING: modification indices for estimator PML are not implemented yet.")
    }

    # sanity check
    if(power) {
        standardized <- TRUE
    }

    # extended list (fixed-to-zero parameters)
    strict.exo <- FALSE
    if(object@Model@conditional.x) {
        strict.exo <- TRUE
    }

    cat("\ncomputing full partable\n\n")

    FULL <- lav_partable_full(partable = object@ParTable,
                              lavpta = object@pta,
                              free = TRUE, start = TRUE,
                              strict.exo = strict.exo)
    FULL$free <- rep(1L, nrow(FULL))
    FULL$user <- rep(10L, nrow(FULL))

    cat("\ncomputed full partable\n\n")

    cat("\ncomputing lav_object_extended\n\n")

    FIT <- lav_object_extended(object, add = FULL, all.free = TRUE)
    LIST <- FIT@ParTable

    cat("\ncomputed lav_object_extended\n\n")

    cat("\n\nfinished lav_partable_full\n")

    # compute information matrix 'extended model'
    # ALWAYS use *expected* information (for now)
    Delta2 <- lavTech(FIT, "information.expected.cc")

    saveRDS(Delta2,"Delta2.Rds")

    cat("\n\nfinished lavTech--information.cc\n")

    # compute gradient 'extended model'
    cat("\n\ncalculating gradient.logl\n")

    score <- lavTech(FIT, "gradient.logl")

#    score = readRDS("score.Rds")

    score = as.matrix(score)

    cat("\n\nlength(score):\n")
    print(dim(score))

    saveRDS(score,"score.Rds")

    cat("\n\nfinished lavTech--gradient.logl\n")


    # Saris, Satorra & Sorbom 1987
    # partition Q into Q_11, Q_22 and Q_12/Q_21
    # which elements of Q correspond with 'free' and 'nonfree' parameters?
    model.idx <- LIST$free[ LIST$free > 0L & LIST$user != 10L ]
    extra.idx <- LIST$free[ LIST$free > 0L & LIST$user == 10L ]

    # catch empty extra.idx (no modification indices!)
    if(length(extra.idx) == 0L) {
        # 2 possibilities: either model is saturated, or we have constraints
        if(object@test[[1]]$df == 0) {
            warning("lavaan WARNING: list with extra parameters is empty; model is saturated")
        } else {
            warning("lavaan WARNING: list with extra parameters is empty; to release equality\n                  constraints, use lavTestScore()")
        }
        LIST <- data.frame(lhs = character(0), op = character(0),
                           rhs = character(0), group = integer(0),
                           mi = numeric(0), epc = numeric(0),
                           sepc.lv = numeric(0), sepc.all = numeric(0),
                           sepc.nox = numeric(0))
        return(LIST)
    }

    cat("\n\nmodel.idx length:\n")
    print(length(model.idx))
    cat("\n\nextra.idx length:\n")
    print(length(extra.idx))

    cat("\n\ngrabbing D2_model\n")
    D2_model = Delta2[,model.idx,drop=FALSE]
    cat("\n\ngrabbed D2_model\n")
    saveRDS(D2_model,"D2_model.Rds")
    cat("\n\ngrabbing D2_extra\n")
    D2_extra = Delta2[,extra.idx,drop=FALSE]
    cat("\n\ngrabbed D2_extra\n")
    saveRDS(D2_extra,"D2_extra.Rds")


#    D2_model = readRDS("D2_model.Rds")
#    D2_extra = readRDS("D2_extra.Rds")

    cat("\n\ncalculating I11.diag\n")
    I11.diag = spam::colSums(D2_extra^2)
    cat("\n\ncalculated I11.diag\n")
    saveRDS(I11.diag,"I11diag.Rds")
    cat("\n\ncalculating I12\n")
    I12 = crossprod.spam(D2_extra,D2_model)
    cat("\n\ncalculated I12\n")
    saveRDS(I12,"I12.Rds")
    cat("\n\ncalculating I22\n")
    I22.diag = spam::colSums(D2_model^2)
    I22.diag = as.matrix(I22.diag)
    cat("\n\ncalculated I22\n")
    saveRDS(I22.diag,"I22diag.Rds")

    cat("\n\nCalculating I22.inv\n")
    print(object)
    # ALWAYS use *expected* information (for now)
    #lavTech(object,paste("inverted.information",information,sep="."))
    I22.inv <- try(lavTech(object, paste("inverted.information",
                                         information, sep = ".")),
                   silent = TRUE)
    # just in case...
    if(inherits(I22.inv, "try-error")) {
        stop("lavaan ERROR: could not compute modification indices; information matrix is singular")
    }

    cat("\n\nCalculated I22.inv\n")

    saveRDS(I22.inv,"I22inv.Rds")

#    I11.diag = readRDS("I11diag.Rds")
    I12 = readRDS("I12.Rds")
    I22.inv = readRDS("I22inv.Rds")

    cat("\n\nstarting V.secondterm_part1 calculation\n")

    secondterm_part1 = I12 %*% as.spam(I22.inv)

    cat("\n\ncalculated V.secondterm_part1\n")

    cat("\n\ncalculating V.secondterm_diag\n")

    print(dim(secondterm_part1))
    print(dim(I12))

    #check
    secondterm_diag = spam::rowSums(secondterm_part1*I12)

    cat("\n\ncalculated V.secondterm_diag\n")

    cat("\n\nlength V.secondterm_diag:\n")
#    print(length(secondterm_diag))
    cat("\n\nlength I11.diag\n")
 #   print(length(I11.diag))

    V.diag = I11.diag - secondterm_diag

    saveRDS(V.diag,"Vdiag.Rds")

    cat("\n\ncalculated V.diag\n")

    # dirty hack: catch very small or negative values in diag(V)
    # this is needed eg when parameters are not identified if freed-up;
    idx <- which(V.diag < sqrt(.Machine$double.eps))
    if(length(idx) > 0L) {
        V.diag[idx] <- as.numeric(NA)
    }

    V.diag = as.matrix(V.diag)

    # create and fill in mi
    if(object@Data@nlevels == 1L) {
        N <- object@SampleStats@ntotal
        if(object@Model@estimator %in% ("ML")) {
            score <- -1 * score # due to gradient.logl
        }
    } else {
        # total number of clusters (over groups)
        N <- 0
        for(g in 1:object@SampleStats@ngroups) {
            N <- N + object@Data@Lp[[g]]$nclusters[[2]]
        }
        #score <- score * (2 * object@SampleStats@ntotal) / N
        score <- score / 2 # -2 * LRT
    }
    mi <- numeric( length(score) )
    cat("\n\ninitialized mi\n")
    print(length(mi))
    mi[extra.idx] <- N * (score[extra.idx]*score[extra.idx]) / V.diag
    cat("\n\ngot mi for all free params\n")
    if(length(model.idx) > 0L) {
        mi[model.idx] <- N * (score[model.idx]*score[model.idx]) / I22.diag
	cat("\n\ngot mi for all fixed params\n")
    }

   cat("\n\nscore[model.idx]\n")
   print(score[model.idx])

   cat("\n\nscore[extra.idx]\n")
   print(tail(score[extra.idx]))

    print(length(mi))

    LIST$mi <- rep(as.numeric(NA), length(LIST$lhs))

    print(length(mi))

    LIST$mi[ LIST$free > 0 ] <- mi

    print(length(mi))


    cat("\n\nadded mi to list\n")

    # handle equality constraints (if any)
    #eq.idx <- which(LIST$op == "==")
    #if(length(eq.idx) > 0L) {
    #    OUT <- lavTestScore(object, warn = FALSE)
    #    LIST$mi[ eq.idx ] <- OUT$uni$X2
    #}

    # scaled?
    #if(length(object@test) > 1L) {
    #    LIST$mi.scaled <- LIST$mi / object@test[[2]]$scaling.factor
    #}

    cat("\n\nlength(score):\n")
    print(length(score))

    # EPC
    d <- (-1 * N) * score
    cat("\n\nlength(d):\n")
    print(length(d))
#    print(abs(d)<as.matrix(1e-15,2,5))
    # needed? probably not; just in case
    d[which(abs(d) < 1e-15)] <- 1.0
    LIST$epc[ LIST$free > 0 ] <- mi/d

    cat("\n\nlength(mi):\n")
    print(length(mi))
    cat("\n\nlength(d):\n")
    print(length(d))

    cat("\n\ndid EPC thing\n")

    # standardize?
    if(standardized) {

        cat("\n\nis standardized\n")
        EPC <- LIST$epc

        if(cov.std) {
            # replace epc values for variances by est values
            var.idx <- which(LIST$op == "~~" & LIST$lhs == LIST$rhs &
                             LIST$exo == 0L)
            EPC[ var.idx ] <- LIST$est[ var.idx ]
        }

        # two problems:
        #   - EPC of variances can be negative, and that is
        #     perfectly legal
        #   - EPC (of variances) can be tiny (near-zero), and we should
        #     not divide by tiny variables
        small.idx <- which(LIST$op == "~~" &
                           LIST$lhs == LIST$rhs &
                           abs(EPC) < sqrt( .Machine$double.eps ) )
        if(length(small.idx) > 0L) {
            EPC[ small.idx ] <- as.numeric(NA)
        }

        # get the sign
        EPC.sign <- sign(LIST$epc)

        LIST$sepc.lv <- EPC.sign * lav_standardize_lv(object,
                                                      partable = LIST,
                                                      est = abs(EPC),
                                                      cov.std = cov.std)
        if(length(small.idx) > 0L) {
            LIST$sepc.lv[small.idx] <- 0
        }
        LIST$sepc.all <- EPC.sign * lav_standardize_all(object,
                                                        partable = LIST,
                                                        est = abs(EPC),
                                                        cov.std = cov.std)
        if(length(small.idx) > 0L) {
            LIST$sepc.all[small.idx] <- 0
        }
        LIST$sepc.nox <- EPC.sign * lav_standardize_all_nox(object,
                                                            partable = LIST,
                                                            est = abs(EPC),
                                                            cov.std = cov.std)
        if(length(small.idx) > 0L) {
            LIST$sepc.nox[small.idx] <- 0
        }

    }

    # power?
    if(power) {
	cat("\n\npower\n")
        LIST$delta <- delta
        # FIXME: this is using epc in unstandardized metric
        #        this would be much more useful in standardized metric
        #        we need a lav_standardize_all.reverse function...
        LIST$ncp <- (LIST$mi / (LIST$epc*LIST$epc)) * (delta*delta)
        LIST$power <- 1 - pchisq(qchisq((1.0 - alpha), df=1),
                                 df=1, ncp=LIST$ncp)
        LIST$decision <- character( length(LIST$power) )

        # five possibilities (Table 6 in Saris, Satorra, van der Veld, 2009)
        mi.significant <- ifelse( 1 - pchisq(LIST$mi, df=1) < alpha,
                                  TRUE, FALSE )
        high.power <- LIST$power > high.power
        # FIXME: sepc.all or epc??
        #epc.high <- LIST$sepc.all > LIST$delta
        epc.high <- LIST$epc > LIST$delta

        LIST$decision[ which(!mi.significant & !high.power)] <- "(i)"
        LIST$decision[ which( mi.significant & !high.power)] <- "**(m)**"
        LIST$decision[ which(!mi.significant &  high.power)] <- "(nm)"
        LIST$decision[ which( mi.significant &  high.power &
                             !epc.high)] <-  "epc:nm"
        LIST$decision[ which( mi.significant &  high.power &
                              epc.high)] <-  "*epc:m*"

        #LIST$decision[ which(mi.significant &  high.power) ] <- "epc"
        #LIST$decision[ which(mi.significant & !high.power) ] <- "***"
        #LIST$decision[ which(!mi.significant & !high.power) ] <- "(i)"
    }

    # remove rows corresponding to 'fixed.x' exogenous parameters
    #exo.idx <- which(LIST$exo == 1L & nchar(LIST$plabel) > 0L)
    #if(length(exo.idx) > 0L) {
    #    LIST <- LIST[-exo.idx,]
    #}

    # remove some columns
    LIST$id <- LIST$ustart <- LIST$exo <- LIST$label <- LIST$plabel <- NULL
    LIST$start <- LIST$free <- LIST$est <- LIST$se <- LIST$prior <- NULL

    cat("\n\nremoved some columns\n")

    if(power) {
        LIST$sepc.lv <- LIST$sepc.nox <- NULL
    }

    # create data.frame
    LIST <- as.data.frame(LIST, stringsAsFactors = FALSE)
    class(LIST) <- c("lavaan.data.frame", "data.frame")

    cat("\n\ncreated data frame\n")

    # remove rows corresponding to 'old' free parameters
    if(free.remove) {
        old.idx <- which(LIST$user != 10L)
        if(length(old.idx) > 0L) {
            LIST <- LIST[-old.idx,]
        }
    }

    cat("\n\nremoved rows corresponding to old free parameters\n")

    # remove rows corresponding to 'equality' constraints
    eq.idx <- which(LIST$op == "==")
    if(length(eq.idx) > 0L) {
        LIST <- LIST[-eq.idx,]
    }

    cat("\n\nremoved rows corresponding to equality constraints\n")

    # remove even more columns
    LIST$user <- NULL

    # remove block/group/level is only single block
    if(lav_partable_nblocks(LIST) == 1L) {
        LIST$block <- NULL
        LIST$group <- NULL
        LIST$level <- NULL
    }

    # sort?
    if(sort.) {
        LIST <- LIST[order(LIST$mi, decreasing = TRUE),]
    }
    if(minimum.value > 0.0) {
        LIST <- LIST[!is.na(LIST$mi) & LIST$mi > minimum.value,]
    }
    if(maximum.number < nrow(LIST)) {
        LIST <- LIST[seq_len(maximum.number),]
    }
    if(na.remove) {
        idx <- which(is.na(LIST$mi))
        if(length(idx) > 0) {
            LIST <- LIST[-idx,]
        }
    }
    if(!is.null(op)) {
        idx <- LIST$op %in% op
        if(length(idx) > 0) {
            LIST <- LIST[idx,]
        }
    }

    # add header
    # TODO: small explanation of the columns in the header?
#    attr(LIST, "header") <-
# c("modification indices for newly added parameters only; to\n",
#   "see the effects of releasing equality constraints, use the\n",
#   "lavTestScore() function")

    LIST
}

# aliases
modificationIndices <- modificationindices <- modindices

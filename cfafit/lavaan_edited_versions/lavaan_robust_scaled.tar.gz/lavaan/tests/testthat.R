library(testthat)
library(lavaan)
# run tests
test_check("lavaan")
